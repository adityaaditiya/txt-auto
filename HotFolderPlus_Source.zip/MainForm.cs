using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Text.Json;
using System.Windows.Forms;

namespace HotFolderPlus
{
    /// <summary>
    /// Main application window. Allows users to manage hot folder rules, start/stop the engine,
    /// and observe log output. Rules are persisted to a JSON file between sessions.
    /// </summary>
    public partial class MainForm : Form
    {
        private readonly BindingList<Rule> _rules = new();
        private Engine? _engine;
        private readonly string _configPath;

        public MainForm()
        {
            InitializeComponent();
            _configPath = Path.Combine(Application.StartupPath, "config.json");
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // Load config from disk if present
            if (File.Exists(_configPath))
            {
                try
                {
                    var json = File.ReadAllText(_configPath);
                    var cfg = JsonSerializer.Deserialize<AppConfig>(json);
                    if (cfg != null)
                    {
                        foreach (var r in cfg.Rules)
                            _rules.Add(r);
                    }
                }
                catch
                {
                    // ignore errors and start with empty list
                }
            }

            gridRules.DataSource = _rules;
            UpdateButtons();
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Save config
            var cfg = new AppConfig { Rules = new List<Rule>(_rules) };
            try
            {
                var json = JsonSerializer.Serialize(cfg, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(_configPath, json);
            }
            catch
            {
                // ignore
            }

            // Stop engine if running
            _engine?.Dispose();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var rule = new Rule { Name = "Rule " + (_rules.Count + 1) };
            using var dlg = new RuleEditorForm(rule);
            if (dlg.ShowDialog(this) == DialogResult.OK)
            {
                _rules.Add(rule);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (gridRules.CurrentRow?.DataBoundItem is Rule rule)
            {
                using var dlg = new RuleEditorForm(rule);
                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    // refresh grid
                    gridRules.Refresh();
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (gridRules.CurrentRow?.DataBoundItem is Rule rule)
            {
                if (MessageBox.Show($"Hapus rule '{rule.Name}'?", "Konfirmasi", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    _rules.Remove(rule);
                }
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (_engine != null) return;
            _engine = new Engine(Log);
            _engine.Start(_rules);
            Log("Engine berjalan");
            UpdateButtons();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            _engine?.Dispose();
            _engine = null;
            Log("Engine berhenti");
            UpdateButtons();
        }

        private void UpdateButtons()
        {
            bool running = _engine != null;
            btnStart.Enabled = !running;
            btnStop.Enabled = running;
            btnAdd.Enabled = !running;
            btnEdit.Enabled = !running && gridRules.CurrentRow != null;
            btnDelete.Enabled = !running && gridRules.CurrentRow != null;
        }

        private void gridRules_SelectionChanged(object sender, EventArgs e)
        {
            UpdateButtons();
        }

        private void Log(string message)
        {
            if (InvokeRequired)
            {
                Invoke(new Action<string>(Log), message);
                return;
            }
            var line = $"{DateTime.Now:HH:mm:ss} - {message}";
            txtLog.AppendText(line + Environment.NewLine);
        }

        #region Designer generated code
        private DataGridView gridRules = null!;
        private Button btnAdd = null!;
        private Button btnEdit = null!;
        private Button btnDelete = null!;
        private Button btnStart = null!;
        private Button btnStop = null!;
        private TextBox txtLog = null!;

        private void InitializeComponent()
        {
            this.gridRules = new System.Windows.Forms.DataGridView();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.txtLog = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.gridRules)).BeginInit();
            this.SuspendLayout();
            // 
            // gridRules
            // 
            this.gridRules.AllowUserToAddRows = false;
            this.gridRules.AllowUserToDeleteRows = false;
            this.gridRules.AutoGenerateColumns = false;
            this.gridRules.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridRules.Location = new System.Drawing.Point(12, 12);
            this.gridRules.MultiSelect = false;
            this.gridRules.Name = "gridRules";
            this.gridRules.ReadOnly = true;
            this.gridRules.RowHeadersVisible = false;
            this.gridRules.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridRules.Size = new System.Drawing.Size(760, 250);
            this.gridRules.TabIndex = 0;
            this.gridRules.SelectionChanged += new System.EventHandler(this.gridRules_SelectionChanged);
            // Define columns
            var colName = new DataGridViewTextBoxColumn { DataPropertyName = "Name", HeaderText = "Nama", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill };
            var colSrc = new DataGridViewTextBoxColumn { DataPropertyName = "SourceFolder", HeaderText = "Folder Sumber", Width = 160 };
            var colFilter = new DataGridViewTextBoxColumn { DataPropertyName = "Filter", HeaderText = "Filter", Width = 120 };
            var colPrinters = new DataGridViewTextBoxColumn { DataPropertyName = "Printers", HeaderText = "Printer", Width = 120 };
            colPrinters.CellTemplate = new DataGridViewTextBoxCell();
            colPrinters.ReadOnly = true;
            var colActions = new DataGridViewTextBoxColumn { HeaderText = "Aksi", Width = 160 };
            colActions.ReadOnly = true;
            var colEnabled = new DataGridViewCheckBoxColumn { DataPropertyName = "Enabled", HeaderText = "Aktif", Width = 50 };
            this.gridRules.Columns.AddRange(new DataGridViewColumn[] { colName, colSrc, colFilter, colPrinters, colActions, colEnabled });
            this.gridRules.CellFormatting += GridRules_CellFormatting;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(12, 268);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 1;
            this.btnAdd.Text = "Tambah";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(93, 268);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(75, 23);
            this.btnEdit.TabIndex = 2;
            this.btnEdit.Text = "Ubah";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(174, 268);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Text = "Hapus";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(482, 268);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(130, 23);
            this.btnStart.TabIndex = 4;
            this.btnStart.Text = "Mulai";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(618, 268);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(130, 23);
            this.btnStop.TabIndex = 5;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // txtLog
            // 
            this.txtLog.Location = new System.Drawing.Point(12, 297);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtLog.Size = new System.Drawing.Size(760, 152);
            this.txtLog.TabIndex = 6;
            this.txtLog.ReadOnly = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.txtLog);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.gridRules);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "HotFolderPlus";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.gridRules)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void GridRules_CellFormatting(object? sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
            var rule = (Rule)gridRules.Rows[e.RowIndex].DataBoundItem;
            // For printer column, join names
            if (gridRules.Columns[e.ColumnIndex].HeaderText == "Printer")
            {
                e.Value = rule.Printers != null && rule.Printers.Count > 0 ? string.Join(", ", rule.Printers) : "Default";
            }
            else if (gridRules.Columns[e.ColumnIndex].HeaderText == "Aksi")
            {
                var actions = new List<string>();
                if (rule.ActionPrint) actions.Add("Print");
                if (rule.ActionCopyToOutput) actions.Add("Copy");
                if (rule.ActionMoveToOutput) actions.Add("Move");
                if (rule.DeleteAfterProcessing) actions.Add("Delete");
                e.Value = string.Join(", ", actions);
            }
        }
        #endregion
    }
}