# HotFolderPlus

HotFolderPlus adalah aplikasi Windows berbasis C# (.NET 8) yang meniru pola kerja **FolderMill**: memantau satu atau beberapa *Hot Folder* dan secara otomatis memproses berkas yang masuk sesuai aturan yang sudah didefinisikan. Proyek ini bertujuan menghadirkan fitur inti FolderMill dalam bentuk sederhana dan open‑source.

## Fitur utama

- **Multi Hot Folder & aturan** – Buat banyak aturan yang masing‑masing memantau folder sumber berbeda. Setiap aturan memiliki filter (mis. `*.txt;*.pdf;*.jpg`), daftar printer, serta aksi: cetak, salin, pindahkan, dan hapus【479708417881223†screenshot】.
- **Cetak ke banyak printer** – Anda dapat memilih beberapa printer untuk sebuah aturan; berkas yang cocok akan dicetak ke setiap printer terpilih【58334514545849†screenshot】. Jika tidak ada printer yang dipilih, printer default sistem dipakai.
- **Filter berbasis masker** – Aturan mendukung beberapa pola (wildcard) dipisahkan titik‑koma, misalnya `*.pdf;*.docx;*.jpg`. Berkas yang cocok akan diproses【808153004465572†screenshot】.
- **Salin / pindahkan ke folder tujuan** – Selain mencetak, berkas dapat disalin atau dipindahkan ke folder keluaran. Bila tidak ada folder keluaran diatur dan opsi “Pindahkan” aktif, berkas akan dihapus setelah diproses.【918473199909226†screenshot】
- **Hapus setelah selesai** – Opsi untuk menghapus berkas asli setelah diproses, baik langsung ataupun setelah disalin/pindah.
- **Mesin pemroses latar** – Mesin memantau folder menggunakan `FileSystemWatcher` dan antrian kerja. Untuk menghindari error file‑lock, mesin menunggu ukuran berkas stabil sebelum memproses.
- **Cetak berbagai tipe berkas**
  - **Teks** (`.txt`) dicetak menggunakan `PrintDocument` bawaan Windows.
  - **Gambar** (`.png`, `.jpg`, `.jpeg`, `.bmp`, `.gif`, `.tif`, `.tiff`) dicetak langsung.
  - **PDF & lainnya** menggunakan `ShellExecute` dengan verb `print`/`printto`, sehingga Windows akan memanggil aplikasi default untuk format tersebut (Adobe Reader, SumatraPDF, dll.). Berkas Office seperti `.docx` atau `.xlsx` akan dicoba diprint oleh aplikasi terkait jika terpasang. Karena terbatas pada asosiasi aplikasi, proses bisa lebih lambat atau muncul dialog.
- **Log real‑time** – Jendela utama menampilkan log aksi seperti “Terdeteksi file…”, “Print…”, “Copy…” sehingga Anda bisa memonitor apa yang terjadi.
- **Simpan konfigurasi** – Semua aturan disimpan ke `config.json` di folder aplikasi dan dimuat otomatis saat aplikasi dijalankan kembali.

> **Catatan keterbatasan**: FolderMill asli adalah produk komersial dengan mesin internal untuk konversi ke PDF/JPG, watermark, OCR, pemrosesan multi‑thread hingga ribuan file, dan integrasi format CAD/ZPL/HTML/Email【998154655783660†screenshot】. HotFolderPlus meniru konsep inti tetapi tidak memiliki fitur konversi lanjutan tersebut. Untuk format non‑teks/gambar/PDF, pencetakan bergantung pada aplikasi default Windows melalui `ShellExecute`. Aplikasi ini ditujukan sebagai contoh edukatif.

## Cara build

Pastikan Anda telah menginstal **.NET 8 SDK** (versi Windows). Kemudian:

```cmd
cd HotFolderPlus
dotnet restore
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
```

Perintah di atas akan menghasilkan berkas `HotFolderPlus.exe` yang mandiri (termasuk runtime .NET) di:

```
HotFolderPlus\bin\Release\net8.0-windows\win-x64\publish\HotFolderPlus.exe
```

Jalankan `HotFolderPlus.exe` untuk membuka aplikasi.

## Cara menggunakan

1. **Tambah Aturan** – Klik **Tambah**, lalu isi:
   - **Nama** rule.
   - **Folder Sumber**: lokasi folder yang ingin dipantau.
   - **Folder Output**: opsional, tempat menyalin atau memindahkan berkas.
   - **Filter**: pola file yang ingin diproses, mis. `*.txt;*.pdf;*.jpg`.
   - Centang **Cetak** jika ingin mencetak, lalu pilih satu atau beberapa printer.
   - Centang **Copy ke Output**, **Move ke Output**, dan/atau **Delete setelah proses** sesuai kebutuhan.
   - Centang **Aktif** agar aturan mulai berlaku saat engine berjalan.
2. **Ubah/Hapus** – Pilih rule pada tabel kemudian klik **Ubah** atau **Hapus**.
3. **Mulai/Stop Engine** – Klik **Mulai** untuk mengaktifkan mesin pemantau. Ketika aktif, aturan baru tidak bisa ditambah di tengah jalan. Klik **Stop** untuk menghentikan sementara.
4. **Lihat Log** – Panel log di bawah menampilkan status setiap aksi.

## Perbedaan dibanding FolderMill

| Fitur | FolderMill | HotFolderPlus |
|------|------------|---------------|
| Monitoring folder & pemicu otomatis | Ya【479708417881223†screenshot】 | Ya |
| Multitindakan (filter, print, copy/move) | Ya【58334514545849†screenshot】 | Ya |
| Dukungan multi-printer | Ya【58334514545849†screenshot】 | Ya (pilih beberapa printer per rule) |
| Konversi ke PDF/JPG/PNG/XPS | Lengkap【998154655783660†screenshot】 | Hanya cetak; konversi tidak tersedia |
| Dukungan puluhan format (DOC, XLS, CAD, ZPL, HTML, email) | Ya【808153004465572†screenshot】 | Bergantung aplikasi default; tidak disediakan converter bawaan |
| Watermark, OCR, arsip & manipulasi lanjutan | Ya【58334514545849†screenshot】【918473199909226†screenshot】 | Tidak |
| Berjalan sebagai layanan 24/7 | Ya【918473199909226†screenshot】 | Aplikasi desktop biasa; dapat berjalan lama namun bukan service |

HotFolderPlus memberikan dasar **“Hot Folder” + aksi print/copy/move** yang sederhana dan mudah dimodifikasi. Untuk fitur lanjutan seperti konversi, watermark, OCR, dan dukungan format industri (CAD, ZPL), Anda perlu menambahkan integrasi ke library pihak ketiga atau menggunakan solusi komersial seperti FolderMill.
