using System;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace HotFolderPlus
{
    /// <summary>
    /// Dialog for creating or editing a single rule. Presents fields for all configurable
    /// properties of <see cref="Rule"/> including multi-printer selection and actions.
    /// </summary>
    public partial class RuleEditorForm : Form
    {
        private readonly Rule _rule;

        public RuleEditorForm(Rule rule)
        {
            _rule = rule;
            InitializeComponent();
        }

        private void RuleEditorForm_Load(object sender, EventArgs e)
        {
            txtName.Text = _rule.Name;
            txtSource.Text = _rule.SourceFolder;
            txtOutput.Text = _rule.OutputFolder;
            txtFilter.Text = _rule.Filter;
            chkPrint.Checked = _rule.ActionPrint;
            chkCopy.Checked = _rule.ActionCopyToOutput;
            chkMove.Checked = _rule.ActionMoveToOutput;
            chkDelete.Checked = _rule.DeleteAfterProcessing;
            chkEnabled.Checked = _rule.Enabled;

            // Populate printer list
            clbPrinters.Items.Clear();
            foreach (string printer in PrinterSettings.InstalledPrinters)
            {
                clbPrinters.Items.Add(printer, _rule.Printers.Contains(printer));
            }
            UpdatePrinterControls();
        }

        private void btnBrowseSource_Click(object sender, EventArgs e)
        {
            using var fbd = new FolderBrowserDialog();
            fbd.SelectedPath = txtSource.Text;
            if (fbd.ShowDialog(this) == DialogResult.OK)
            {
                txtSource.Text = fbd.SelectedPath;
            }
        }

        private void btnBrowseOutput_Click(object sender, EventArgs e)
        {
            using var fbd = new FolderBrowserDialog();
            fbd.SelectedPath = txtOutput.Text;
            if (fbd.ShowDialog(this) == DialogResult.OK)
            {
                txtOutput.Text = fbd.SelectedPath;
            }
        }

        private void chkPrint_CheckedChanged(object sender, EventArgs e)
        {
            UpdatePrinterControls();
        }

        private void UpdatePrinterControls()
        {
            clbPrinters.Enabled = chkPrint.Checked;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Nama rule tidak boleh kosong.");
                return;
            }
            if (string.IsNullOrWhiteSpace(txtSource.Text) || !Directory.Exists(txtSource.Text))
            {
                MessageBox.Show("Folder sumber tidak valid.");
                return;
            }
            // update rule
            _rule.Name = txtName.Text;
            _rule.SourceFolder = txtSource.Text;
            _rule.OutputFolder = txtOutput.Text;
            _rule.Filter = txtFilter.Text;
            _rule.ActionPrint = chkPrint.Checked;
            _rule.ActionCopyToOutput = chkCopy.Checked;
            _rule.ActionMoveToOutput = chkMove.Checked;
            _rule.DeleteAfterProcessing = chkDelete.Checked;
            _rule.Enabled = chkEnabled.Checked;
            // update printers
            _rule.Printers.Clear();
            foreach (var item in clbPrinters.CheckedItems)
            {
                _rule.Printers.Add(item.ToString()!);
            }
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        #region Designer generated code
        private TextBox txtName = null!;
        private TextBox txtSource = null!;
        private TextBox txtOutput = null!;
        private TextBox txtFilter = null!;
        private CheckedListBox clbPrinters = null!;
        private CheckBox chkPrint = null!;
        private CheckBox chkCopy = null!;
        private CheckBox chkMove = null!;
        private CheckBox chkDelete = null!;
        private CheckBox chkEnabled = null!;
        private Button btnOk = null!;
        private Button btnCancel = null!;
        private Button btnBrowseSource = null!;
        private Button btnBrowseOutput = null!;
        private Label lblName = null!;
        private Label lblSource = null!;
        private Label lblOutput = null!;
        private Label lblFilter = null!;
        private Label lblPrinters = null!;

        private void InitializeComponent()
        {
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtSource = new System.Windows.Forms.TextBox();
            this.txtOutput = new System.Windows.Forms.TextBox();
            this.txtFilter = new System.Windows.Forms.TextBox();
            this.clbPrinters = new System.Windows.Forms.CheckedListBox();
            this.chkPrint = new System.Windows.Forms.CheckBox();
            this.chkCopy = new System.Windows.Forms.CheckBox();
            this.chkMove = new System.Windows.Forms.CheckBox();
            this.chkDelete = new System.Windows.Forms.CheckBox();
            this.chkEnabled = new System.Windows.Forms.CheckBox();
            this.btnOk = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnBrowseSource = new System.Windows.Forms.Button();
            this.btnBrowseOutput = new System.Windows.Forms.Button();
            this.lblName = new System.Windows.Forms.Label();
            this.lblSource = new System.Windows.Forms.Label();
            this.lblOutput = new System.Windows.Forms.Label();
            this.lblFilter = new System.Windows.Forms.Label();
            this.lblPrinters = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(12, 15);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(37, 15);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Nama";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(100, 12);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(300, 23);
            this.txtName.TabIndex = 1;
            // 
            // lblSource
            // 
            this.lblSource.AutoSize = true;
            this.lblSource.Location = new System.Drawing.Point(12, 46);
            this.lblSource.Name = "lblSource";
            this.lblSource.Size = new System.Drawing.Size(82, 15);
            this.lblSource.TabIndex = 2;
            this.lblSource.Text = "Folder Sumber";
            // 
            // txtSource
            // 
            this.txtSource.Location = new System.Drawing.Point(100, 43);
            this.txtSource.Name = "txtSource";
            this.txtSource.Size = new System.Drawing.Size(260, 23);
            this.txtSource.TabIndex = 3;
            // 
            // btnBrowseSource
            // 
            this.btnBrowseSource.Location = new System.Drawing.Point(366, 43);
            this.btnBrowseSource.Name = "btnBrowseSource";
            this.btnBrowseSource.Size = new System.Drawing.Size(34, 23);
            this.btnBrowseSource.TabIndex = 4;
            this.btnBrowseSource.Text = "...";
            this.btnBrowseSource.UseVisualStyleBackColor = true;
            this.btnBrowseSource.Click += new System.EventHandler(this.btnBrowseSource_Click);
            // 
            // lblOutput
            // 
            this.lblOutput.AutoSize = true;
            this.lblOutput.Location = new System.Drawing.Point(12, 77);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(80, 15);
            this.lblOutput.TabIndex = 5;
            this.lblOutput.Text = "Folder Output";
            // 
            // txtOutput
            // 
            this.txtOutput.Location = new System.Drawing.Point(100, 74);
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.Size = new System.Drawing.Size(260, 23);
            this.txtOutput.TabIndex = 6;
            // 
            // btnBrowseOutput
            // 
            this.btnBrowseOutput.Location = new System.Drawing.Point(366, 74);
            this.btnBrowseOutput.Name = "btnBrowseOutput";
            this.btnBrowseOutput.Size = new System.Drawing.Size(34, 23);
            this.btnBrowseOutput.TabIndex = 7;
            this.btnBrowseOutput.Text = "...";
            this.btnBrowseOutput.UseVisualStyleBackColor = true;
            this.btnBrowseOutput.Click += new System.EventHandler(this.btnBrowseOutput_Click);
            // 
            // lblFilter
            // 
            this.lblFilter.AutoSize = true;
            this.lblFilter.Location = new System.Drawing.Point(12, 108);
            this.lblFilter.Name = "lblFilter";
            this.lblFilter.Size = new System.Drawing.Size(35, 15);
            this.lblFilter.TabIndex = 8;
            this.lblFilter.Text = "Filter";
            // 
            // txtFilter
            // 
            this.txtFilter.Location = new System.Drawing.Point(100, 105);
            this.txtFilter.Name = "txtFilter";
            this.txtFilter.Size = new System.Drawing.Size(300, 23);
            this.txtFilter.TabIndex = 9;
            // 
            // chkPrint
            // 
            this.chkPrint.AutoSize = true;
            this.chkPrint.Location = new System.Drawing.Point(100, 134);
            this.chkPrint.Name = "chkPrint";
            this.chkPrint.Size = new System.Drawing.Size(88, 19);
            this.chkPrint.TabIndex = 10;
            this.chkPrint.Text = "Cetak (Print)";
            this.chkPrint.UseVisualStyleBackColor = true;
            this.chkPrint.CheckedChanged += new System.EventHandler(this.chkPrint_CheckedChanged);
            // 
            // lblPrinters
            // 
            this.lblPrinters.AutoSize = true;
            this.lblPrinters.Location = new System.Drawing.Point(12, 162);
            this.lblPrinters.Name = "lblPrinters";
            this.lblPrinters.Size = new System.Drawing.Size(45, 15);
            this.lblPrinters.TabIndex = 11;
            this.lblPrinters.Text = "Printer";
            // 
            // clbPrinters
            // 
            this.clbPrinters.CheckOnClick = true;
            this.clbPrinters.FormattingEnabled = true;
            this.clbPrinters.Location = new System.Drawing.Point(100, 162);
            this.clbPrinters.Name = "clbPrinters";
            this.clbPrinters.Size = new System.Drawing.Size(300, 94);
            this.clbPrinters.TabIndex = 12;
            // 
            // chkCopy
            // 
            this.chkCopy.AutoSize = true;
            this.chkCopy.Location = new System.Drawing.Point(100, 262);
            this.chkCopy.Name = "chkCopy";
            this.chkCopy.Size = new System.Drawing.Size(102, 19);
            this.chkCopy.TabIndex = 13;
            this.chkCopy.Text = "Copy ke Output";
            this.chkCopy.UseVisualStyleBackColor = true;
            // 
            // chkMove
            // 
            this.chkMove.AutoSize = true;
            this.chkMove.Location = new System.Drawing.Point(100, 287);
            this.chkMove.Name = "chkMove";
            this.chkMove.Size = new System.Drawing.Size(105, 19);
            this.chkMove.TabIndex = 14;
            this.chkMove.Text = "Move ke Output";
            this.chkMove.UseVisualStyleBackColor = true;
            // 
            // chkDelete
            // 
            this.chkDelete.AutoSize = true;
            this.chkDelete.Location = new System.Drawing.Point(100, 312);
            this.chkDelete.Name = "chkDelete";
            this.chkDelete.Size = new System.Drawing.Size(139, 19);
            this.chkDelete.TabIndex = 15;
            this.chkDelete.Text = "Delete setelah proses";
            this.chkDelete.UseVisualStyleBackColor = true;
            // 
            // chkEnabled
            // 
            this.chkEnabled.AutoSize = true;
            this.chkEnabled.Location = new System.Drawing.Point(100, 337);
            this.chkEnabled.Name = "chkEnabled";
            this.chkEnabled.Size = new System.Drawing.Size(54, 19);
            this.chkEnabled.TabIndex = 16;
            this.chkEnabled.Text = "Aktif";
            this.chkEnabled.UseVisualStyleBackColor = true;
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(244, 367);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 17;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(325, 367);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 18;
            this.btnCancel.Text = "Batal";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // RuleEditorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 402);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.chkEnabled);
            this.Controls.Add(this.chkDelete);
            this.Controls.Add(this.chkMove);
            this.Controls.Add(this.chkCopy);
            this.Controls.Add(this.clbPrinters);
            this.Controls.Add(this.lblPrinters);
            this.Controls.Add(this.chkPrint);
            this.Controls.Add(this.txtFilter);
            this.Controls.Add(this.lblFilter);
            this.Controls.Add(this.btnBrowseOutput);
            this.Controls.Add(this.txtOutput);
            this.Controls.Add(this.lblOutput);
            this.Controls.Add(this.btnBrowseSource);
            this.Controls.Add(this.txtSource);
            this.Controls.Add(this.lblSource);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "RuleEditorForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Rule Editor";
            this.Load += new System.EventHandler(this.RuleEditorForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion
    }
}