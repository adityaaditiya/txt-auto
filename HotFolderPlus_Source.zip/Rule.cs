using System;
using System.Collections.Generic;

namespace HotFolderPlus
{
    /// <summary>
    /// Represents a single hot-folder rule. Each rule defines a source folder and a set of actions
    /// to perform on any file that matches the configured filter. Actions include printing to one
    /// or more printers, copying or moving to an output folder, and optionally deleting the original
    /// file after processing.
    /// </summary>
    public class Rule
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string Name { get; set; } = "Rule";

        /// <summary>
        /// Path of the folder to monitor for new files.
        /// </summary>
        public string SourceFolder { get; set; } = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

        /// <summary>
        /// Path of the folder to copy or move files to. If empty and ActionMoveToOutput is true, the original
        /// file will be deleted after processing.
        /// </summary>
        public string OutputFolder { get; set; } = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

        /// <summary>
        /// File mask(s) to filter incoming files. Supports multiple masks separated by semicolon (e.g. "*.txt;*.pdf").
        /// </summary>
        public string Filter { get; set; } = "*.txt;*.pdf;*.png;*.jpg;*.jpeg";

        /// <summary>
        /// List of printer names to print to. If empty, the system default printer will be used.
        /// </summary>
        public List<string> Printers { get; set; } = new();

        public bool ActionPrint { get; set; } = true;
        public bool ActionCopyToOutput { get; set; } = false;
        public bool ActionMoveToOutput { get; set; } = false;

        /// <summary>
        /// If true and ActionMoveToOutput is also true, the processed file will be deleted instead of moved. If
        /// ActionMoveToOutput is false and DeleteAfterProcessing is true, the file will be deleted after processing
        /// without copying.
        /// </summary>
        public bool DeleteAfterProcessing { get; set; } = false;

        /// <summary>
        /// Determines if the rule is enabled.
        /// </summary>
        public bool Enabled { get; set; } = false;
    }

    /// <summary>
    /// Configuration container for the application.
    /// </summary>
    public class AppConfig
    {
        public List<Rule> Rules { get; set; } = new();
    }
}