using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Windows.Forms;

namespace HotFolderPlus
{
    /// <summary>
    /// Main window for HotFolderPlus with paper and margin settings. Displays rules and
    /// allows starting/stopping the engine. Configurations are persisted to the user's
    /// AppData folder.
    /// </summary>
    public class MainForm : Form
    {
        private readonly ListView _rulesView;
        private readonly Button _btnAdd, _btnEdit, _btnRemove, _btnSave, _btnStart, _btnStop;
        private readonly ListBox _logList;
        private Engine? _engine;
        private AppConfig _config;
        private readonly string _configPath;

        public MainForm()
        {
            Text = "HotFolderPlus – Hot Folder Printer/Actions";
            Width = 1000;
            Height = 660;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            _rulesView = new ListView
            {
                Left = 20,
                Top = 20,
                Width = 950,
                Height = 340,
                View = View.Details,
                FullRowSelect = true,
                GridLines = true
            };
            _rulesView.Columns.Add("Nama", 160);
            _rulesView.Columns.Add("Sumber", 220);
            _rulesView.Columns.Add("Filter", 120);
            _rulesView.Columns.Add("Printers", 180);
            _rulesView.Columns.Add("Kertas", 120);
            _rulesView.Columns.Add("Margin (mm)", 130);
            _rulesView.Columns.Add("Aktif", 50);

            _btnAdd = new Button { Text = "Tambah", Left = 20, Top = 370, Width = 90 };
            _btnEdit = new Button { Text = "Ubah", Left = 120, Top = 370, Width = 90 };
            _btnRemove = new Button { Text = "Hapus", Left = 220, Top = 370, Width = 90 };
            _btnSave = new Button { Text = "Simpan", Left = 320, Top = 370, Width = 90 };
            _btnStart = new Button { Text = "Mulai", Left = 780, Top = 370, Width = 80 };
            _btnStop = new Button { Text = "Stop", Left = 870, Top = 370, Width = 80, Enabled = false };

            _logList = new ListBox { Left = 20, Top = 410, Width = 950, Height = 200 };

            Controls.AddRange(new Control[] { _rulesView, _btnAdd, _btnEdit, _btnRemove, _btnSave, _btnStart, _btnStop, _logList });

            _btnAdd.Click += (s, e) => AddRule();
            _btnEdit.Click += (s, e) => EditRule();
            _btnRemove.Click += (s, e) => RemoveRule();
            _btnSave.Click += (s, e) => SaveConfig();
            _btnStart.Click += (s, e) => StartEngine();
            _btnStop.Click += (s, e) => StopEngine();

            _configPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "HotFolderPlus_PaperMargin", "config.json");
            Directory.CreateDirectory(Path.GetDirectoryName(_configPath)!);
            _config = LoadConfig();
            RefreshList();
        }

        private AppConfig LoadConfig()
        {
            try
            {
                if (File.Exists(_configPath))
                {
                    var json = File.ReadAllText(_configPath);
                    var cfg = JsonSerializer.Deserialize<AppConfig>(json, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                    if (cfg != null) return cfg;
                }
            }
            catch { }
            return new AppConfig();
        }

        private void SaveConfig()
        {
            var json = JsonSerializer.Serialize(_config, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(_configPath, json);
            Log("Konfigurasi disimpan.");
        }

        private void RefreshList()
        {
            _rulesView.Items.Clear();
            foreach (var r in _config.Rules)
            {
                string printers = (r.Printers == null || r.Printers.Count == 0) ? "(Default)" : string.Join(" | ", r.Printers);
                string paper = r.PaperMode.ToString() + (r.PaperMode == PaperMode.Custom ? string.Format(" {0}x{1}mm", r.CustomWidthMm, r.CustomHeightMm) : string.Empty);
                string margins = string.Format("{0},{1},{2},{3}", r.MarginLeftMm, r.MarginTopMm, r.MarginRightMm, r.MarginBottomMm);
                var item = new ListViewItem(new[]
                {
                    r.Name,
                    r.SourceFolder,
                    r.Filter,
                    printers,
                    paper,
                    margins,
                    r.Enabled ? "Ya" : "Tidak"
                })
                {
                    Tag = r
                };
                _rulesView.Items.Add(item);
            }
        }

        private void AddRule()
        {
            var r = new Rule { Name = "Rule " + (_config.Rules.Count + 1) };
            using var dlg = new RuleEditorForm(r);
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                _config.Rules.Add(r);
                RefreshList();
            }
        }

        private void EditRule()
        {
            if (_rulesView.SelectedItems.Count == 0) return;
            var r = (Rule)_rulesView.SelectedItems[0].Tag;
            using var dlg = new RuleEditorForm(r);
            if (dlg.ShowDialog() == DialogResult.OK) RefreshList();
        }

        private void RemoveRule()
        {
            if (_rulesView.SelectedItems.Count == 0) return;
            var r = (Rule)_rulesView.SelectedItems[0].Tag;
            _config.Rules.Remove(r);
            RefreshList();
        }

        private void StartEngine()
        {
            SaveConfig();
            _engine?.Dispose();
            _engine = new Engine(Log);
            _engine.Start(_config.Rules);
            _btnStart.Enabled = false;
            _btnStop.Enabled = true;
            Log("Engine berjalan. Memantau semua Rule aktif.");
        }

        private void StopEngine()
        {
            _engine?.Stop();
            _engine?.Dispose();
            _engine = null;
            _btnStart.Enabled = true;
            _btnStop.Enabled = false;
            Log("Engine berhenti.");
        }

        private void Log(string message)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new Action<string>(Log), message);
                return;
            }
            var ts = DateTime.Now.ToString("HH:mm:ss");
            _logList.Items.Insert(0, $"[" + ts + "] " + message);
            if (_logList.Items.Count > 1000) _logList.Items.RemoveAt(_logList.Items.Count - 1);
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _engine?.Dispose();
            base.OnFormClosing(e);
        }
    }
}