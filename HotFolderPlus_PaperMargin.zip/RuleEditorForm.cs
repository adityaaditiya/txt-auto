using System;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace HotFolderPlus
{
    /// <summary>
    /// Editor dialog for creating or modifying a single rule. Supports selection of multiple
    /// printers, paper modes, custom sizes, margins, and printing/copy/move/delete actions.
    /// </summary>
    public class RuleEditorForm : Form
    {
        private readonly TextBox _txtName, _txtSource, _txtOutput, _txtFilter;
        private readonly CheckedListBox _clbPrinters;
        private readonly ComboBox _cboPaperMode;
        private readonly NumericUpDown _numWidth, _numHeight, _numLeft, _numTop, _numRight, _numBottom;
        private readonly CheckBox _chkPrint, _chkCopy, _chkMove, _chkDelete, _chkEnabled;
        private readonly Button _btnBrowseSrc, _btnBrowseOut, _btnOk, _btnCancel;
        private readonly Rule _rule;

        public RuleEditorForm(Rule rule)
        {
            _rule = rule;
            Text = "Edit Rule";
            Width = 780;
            Height = 420;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterParent;
            MaximizeBox = false;
            MinimizeBox = false;

            int L = 20;

            // Name
            Controls.Add(new Label { Text = "Nama", Left = L, Top = 18, Width = 130 });
            _txtName = new TextBox { Left = 160, Top = 14, Width = 580, Text = _rule.Name };
            Controls.Add(_txtName);

            // Source folder
            Controls.Add(new Label { Text = "Folder Sumber", Left = L, Top = 52, Width = 130 });
            _txtSource = new TextBox { Left = 160, Top = 48, Width = 520, Text = _rule.SourceFolder };
            Controls.Add(_txtSource);
            _btnBrowseSrc = new Button { Text = "...", Left = 690, Top = 47, Width = 50 };
            _btnBrowseSrc.Click += (s, e) => { using var fb = new FolderBrowserDialog(); if (fb.ShowDialog() == DialogResult.OK) _txtSource.Text = fb.SelectedPath; };
            Controls.Add(_btnBrowseSrc);

            // Output folder
            Controls.Add(new Label { Text = "Folder Output", Left = L, Top = 86, Width = 130 });
            _txtOutput = new TextBox { Left = 160, Top = 82, Width = 520, Text = _rule.OutputFolder };
            Controls.Add(_txtOutput);
            _btnBrowseOut = new Button { Text = "...", Left = 690, Top = 81, Width = 50 };
            _btnBrowseOut.Click += (s, e) => { using var fb = new FolderBrowserDialog(); if (fb.ShowDialog() == DialogResult.OK) _txtOutput.Text = fb.SelectedPath; };
            Controls.Add(_btnBrowseOut);

            // Filter
            Controls.Add(new Label { Text = "Filter", Left = L, Top = 120, Width = 130 });
            _txtFilter = new TextBox { Left = 160, Top = 116, Width = 580, Text = _rule.Filter };
            Controls.Add(_txtFilter);

            // Printers
            Controls.Add(new Label { Text = "Printers", Left = L, Top = 154, Width = 130 });
            _clbPrinters = new CheckedListBox { Left = 160, Top = 150, Width = 280, Height = 120 };
            _clbPrinters.Items.Add("(Default)");
            foreach (string p in PrinterSettings.InstalledPrinters) _clbPrinters.Items.Add(p);
            if (_rule.Printers != null && _rule.Printers.Count > 0)
            {
                for (int i = 0; i < _clbPrinters.Items.Count; i++)
                {
                    var name = _clbPrinters.Items[i].ToString();
                    if (name != "(Default)" && _rule.Printers.Contains(name)) _clbPrinters.SetItemChecked(i, true);
                }
            }
            Controls.Add(_clbPrinters);

            // Paper mode
            Controls.Add(new Label { Text = "Mode Kertas", Left = 460, Top = 154, Width = 120 });
            _cboPaperMode = new ComboBox { Left = 580, Top = 150, Width = 160, DropDownStyle = ComboBoxStyle.DropDownList };
            _cboPaperMode.Items.AddRange(new object[] { "Default", "Thermal58", "Thermal80", "Custom" });
            _cboPaperMode.SelectedIndex = (int)_rule.PaperMode;
            Controls.Add(_cboPaperMode);

            // Custom size
            Controls.Add(new Label { Text = "Custom W x H (mm)", Left = 460, Top = 184, Width = 120 });
            _numWidth = new NumericUpDown { Left = 580, Top = 180, Width = 70, Minimum = 20, Maximum = 1000, Value = _rule.CustomWidthMm };
            _numHeight = new NumericUpDown { Left = 660, Top = 180, Width = 70, Minimum = 50, Maximum = 3000, Value = _rule.CustomHeightMm };
            Controls.Add(_numWidth);
            Controls.Add(_numHeight);

            // Margins
            Controls.Add(new Label { Text = "Margin (mm) L/T/R/B:", Left = 460, Top = 214, Width = 120 });
            _numLeft = new NumericUpDown { Left = 580, Top = 210, Width = 50, Minimum = 0, Maximum = 50, Value = _rule.MarginLeftMm };
            _numTop = new NumericUpDown { Left = 630, Top = 210, Width = 50, Minimum = 0, Maximum = 50, Value = _rule.MarginTopMm };
            _numRight = new NumericUpDown { Left = 680, Top = 210, Width = 50, Minimum = 0, Maximum = 50, Value = _rule.MarginRightMm };
            _numBottom = new NumericUpDown { Left = 730, Top = 210, Width = 50, Minimum = 0, Maximum = 50, Value = _rule.MarginBottomMm };
            Controls.Add(_numLeft);
            Controls.Add(_numTop);
            Controls.Add(_numRight);
            Controls.Add(_numBottom);

            // Actions
            _chkPrint = new CheckBox { Text = "Cetak", Left = 160, Top = 286, Checked = _rule.ActionPrint };
            _chkCopy = new CheckBox { Text = "Salin ke Output", Left = 240, Top = 286, Checked = _rule.ActionCopyToOutput };
            _chkMove = new CheckBox { Text = "Pindah ke Output", Left = 360, Top = 286, Checked = _rule.ActionMoveToOutput };
            _chkDelete = new CheckBox { Text = "Hapus setelah proses", Left = 500, Top = 286, Checked = _rule.DeleteAfterProcessing };
            _chkEnabled = new CheckBox { Text = "Aktif", Left = 690, Top = 286, Checked = _rule.Enabled };
            Controls.AddRange(new Control[] { _chkPrint, _chkCopy, _chkMove, _chkDelete, _chkEnabled });

            // OK/Cancel
            _btnOk = new Button { Text = "OK", Left = 580, Top = 330, Width = 80 };
            _btnCancel = new Button { Text = "Batal", Left = 670, Top = 330, Width = 80 };
            _btnOk.Click += (s, e) => { Save(); DialogResult = DialogResult.OK; Close(); };
            _btnCancel.Click += (s, e) => { DialogResult = DialogResult.Cancel; Close(); };
            Controls.Add(_btnOk);
            Controls.Add(_btnCancel);
        }

        private void Save()
        {
            _rule.Name = _txtName.Text.Trim();
            _rule.SourceFolder = _txtSource.Text.Trim();
            _rule.OutputFolder = _txtOutput.Text.Trim();
            _rule.Filter = _txtFilter.Text.Trim();
            _rule.Printers.Clear();
            for (int i = 0; i < _clbPrinters.Items.Count; i++)
            {
                if (_clbPrinters.GetItemChecked(i))
                {
                    var name = _clbPrinters.Items[i].ToString();
                    if (name != "(Default)") _rule.Printers.Add(name);
                }
            }
            _rule.PaperMode = (PaperMode)_cboPaperMode.SelectedIndex;
            _rule.CustomWidthMm = (int)_numWidth.Value;
            _rule.CustomHeightMm = (int)_numHeight.Value;
            _rule.MarginLeftMm = (int)_numLeft.Value;
            _rule.MarginTopMm = (int)_numTop.Value;
            _rule.MarginRightMm = (int)_numRight.Value;
            _rule.MarginBottomMm = (int)_numBottom.Value;
            _rule.ActionPrint = _chkPrint.Checked;
            _rule.ActionCopyToOutput = _chkCopy.Checked;
            _rule.ActionMoveToOutput = _chkMove.Checked;
            _rule.DeleteAfterProcessing = _chkDelete.Checked;
            _rule.Enabled = _chkEnabled.Checked;
        }
    }
}