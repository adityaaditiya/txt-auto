# HotFolderPlus – Versi Paper & Margin

HotFolderPlus adalah aplikasi Windows yang memantau folder (*hot folder*) dan secara otomatis memproses berkas yang masuk—misalnya mencetak, menyalin, memindahkan, atau menghapusnya—berdasarkan aturan. Versi ini menambahkan dukungan untuk memilih ukuran kertas dan mengatur margin cetak.

## Fitur Tambahan

* **Mode kertas**: Pilih ukuran kertas yang akan digunakan saat mencetak. Opsi yang tersedia:
  * **Default** – gunakan pengaturan printer.
  * **Thermal 58 mm** – lebar 58 mm, tinggi mengikuti nilai custom height.
  * **Thermal 80 mm** – lebar 80 mm, tinggi mengikuti nilai custom height.
  * **Custom** – tentukan lebar dan tinggi (mm) secara manual.
* **Margin**: Atur margin kiri, atas, kanan, dan bawah dalam milimeter. Nilai margin dikonversi ke satuan *hundredths of an inch* sebelum diterapkan ke `PrintDocument.DefaultPageSettings`.

Pengaturan kertas dan margin diterapkan saat mencetak berkas teks atau gambar. Untuk file PDF dan format lain, aplikasi tetap menggunakan `ShellExecute` sehingga pencetakan ditangani oleh aplikasi default Windows.

## Cara Build

Pastikan .NET 8 SDK terpasang. Kemudian jalankan perintah berikut dari folder proyek:

```cmd
dotnet restore
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
```

File `.exe` akan tersedia di `bin\Release\net8.0-windows\win-x64\publish\HotFolderPlus.exe`.

## Cara Menggunakan

1. Jalankan `HotFolderPlus.exe`.
2. Klik **Tambah** untuk membuat aturan baru. Isi nama rule, folder sumber, folder output (jika diperlukan), pola filter berkas, pilih printer (boleh lebih dari satu), tentukan mode kertas dan ukuran bila `Custom`, serta margin.
3. Pilih aksi yang diinginkan: Cetak, Salin, Pindah, Hapus setelah proses. Centang **Aktif** untuk mengaktifkan rule.
4. Klik **Mulai** untuk memulai pemantauan folder. Klik **Stop** untuk menghentikan mesin.
5. Log proses akan ditampilkan pada kotak log.

Catatan: Printer thermal sering kali mengabaikan tinggi kertas custom karena roll kertas berjalan terus. Jika cetakan terpotong, gunakan nilai tinggi yang lebih besar atau atur driver printer agar memotong kertas sesuai konten.