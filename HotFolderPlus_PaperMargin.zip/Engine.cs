using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace HotFolderPlus
{
    /// <summary>
    /// Core engine responsible for monitoring hot folders and processing detected files.
    /// Adds page setup logic to accommodate paper size and margin settings when printing.
    /// </summary>
    public class Engine : IDisposable
    {
        private readonly Action<string> _log;
        private readonly Dictionary<Guid, FileSystemWatcher> _watchers = new();
        private readonly ConcurrentQueue<(Rule rule, string path)> _queue = new();
        private readonly System.Windows.Forms.Timer _timer;
        private volatile bool _busy;

        public Engine(Action<string> logger)
        {
            _log = logger;
            _timer = new System.Windows.Forms.Timer { Interval = 400 };
            _timer.Tick += (s, e) => ProcessQueue();
        }

        public void Start(IEnumerable<Rule> rules)
        {
            Stop();
            foreach (var r in rules.Where(r => r.Enabled))
            {
                try
                {
                    if (!Directory.Exists(r.SourceFolder))
                    {
                        _log($"Folder tidak ditemukan: {r.SourceFolder}");
                        continue;
                    }
                    var fsw = new FileSystemWatcher(r.SourceFolder)
                    {
                        IncludeSubdirectories = false,
                        NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite | NotifyFilters.Size
                    };
                    fsw.Created += (s, e) => OnNewFile(r, e.FullPath);
                    fsw.Renamed += (s, e) => OnNewFile(r, e.FullPath);
                    fsw.EnableRaisingEvents = true;
                    _watchers[r.Id] = fsw;
                    _log($"Memantau: {r.Name} -> {r.SourceFolder} (filter: {r.Filter})");
                }
                catch (Exception ex)
                {
                    _log($"Gagal memulai watcher untuk {r.Name}: {ex.Message}");
                }
            }
            _timer.Start();
        }

        public void Stop()
        {
            _timer.Stop();
            foreach (var kv in _watchers) kv.Value.Dispose();
            _watchers.Clear();
        }

        private void OnNewFile(Rule rule, string path)
        {
            if (!MatchesFilter(rule.Filter, Path.GetFileName(path))) return;
            _queue.Enqueue((rule, path));
            _log($"Terdeteksi: {Path.GetFileName(path)} (rule: {rule.Name})");
        }

        private bool MatchesFilter(string filter, string fileName)
        {
            if (string.IsNullOrWhiteSpace(filter)) return true;
            var masks = filter.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            foreach (var mask in masks)
                if (IsWildcardMatch(fileName, mask)) return true;
            return false;
        }

        private bool IsWildcardMatch(string input, string pattern)
        {
            string regex = "^" + System.Text.RegularExpressions.Regex.Escape(pattern)
                .Replace("\\*", ".*")
                .Replace("\\?", ".") + "$";
            return System.Text.RegularExpressions.Regex.IsMatch(input, regex, System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        }

        private bool WaitForReady(string path, int timeoutMs = 15000)
        {
            var sw = Stopwatch.StartNew();
            long lastSize = -1;
            while (sw.ElapsedMilliseconds < timeoutMs)
            {
                try
                {
                    var fi = new FileInfo(path);
                    if (!fi.Exists) { Thread.Sleep(200); continue; }
                    using var stream = File.Open(path, FileMode.Open, FileAccess.Read, FileShare.Read);
                    if (fi.Length == lastSize) return true;
                    lastSize = fi.Length;
                }
                catch { }
                Thread.Sleep(250);
            }
            return false;
        }

        private void ProcessQueue()
        {
            if (_busy) return;
            if (!_queue.TryDequeue(out var item)) return;
            var (rule, path) = item;
            if (!WaitForReady(path)) { _log($"Timeout akses: {Path.GetFileName(path)}"); return; }

            try
            {
                _busy = true;
                if (rule.ActionPrint) PrintFile(path, rule);
                if (rule.ActionCopyToOutput) CopyTo(path, rule.OutputFolder, move: false);
                if (rule.ActionMoveToOutput)
                {
                    if (rule.DeleteAfterProcessing || string.IsNullOrWhiteSpace(rule.OutputFolder))
                    {
                        File.Delete(path);
                        _log($"Delete: {Path.GetFileName(path)}");
                    }
                    else CopyTo(path, rule.OutputFolder, move: true);
                }
                else if (rule.DeleteAfterProcessing)
                {
                    File.Delete(path);
                    _log($"Delete: {Path.GetFileName(path)}");
                }
            }
            catch (Exception ex)
            {
                _log($"Error proses {Path.GetFileName(path)}: {ex.Message}");
            }
            finally
            {
                _busy = false;
            }
        }

        private void CopyTo(string path, string outDir, bool move)
        {
            if (string.IsNullOrWhiteSpace(outDir)) return;
            try
            {
                Directory.CreateDirectory(outDir);
                var dest = Path.Combine(outDir, Path.GetFileName(path));
                if (move) File.Move(path, dest, overwrite: true);
                else File.Copy(path, dest, overwrite: true);
                _log($"{(move ? "Move" : "Copy")}: {Path.GetFileName(path)} -> {outDir}");
            }
            catch (Exception ex)
            {
                _log($"Error {(move ? "move" : "copy")}: {ex.Message}");
            }
        }

        private void ApplyPageSettings(PrintDocument doc, Rule rule)
        {
            int MmToHundredths(int mm) => (int)Math.Round(mm / 25.4 * 100.0);
            doc.DefaultPageSettings.Margins = new Margins(
                MmToHundredths(rule.MarginLeftMm),
                MmToHundredths(rule.MarginRightMm),
                MmToHundredths(rule.MarginTopMm),
                MmToHundredths(rule.MarginBottomMm)
            );
            if (rule.PaperMode == PaperMode.Default) return;
            int widthMm = rule.PaperMode switch
            {
                PaperMode.Thermal58 => 58,
                PaperMode.Thermal80 => 80,
                PaperMode.Custom => Math.Max(20, rule.CustomWidthMm),
                _ => 58
            };
            int heightMm = (rule.PaperMode == PaperMode.Custom)
                ? Math.Max(50, rule.CustomHeightMm)
                : Math.Max(100, rule.CustomHeightMm);
            int w = MmToHundredths(widthMm);
            int h = MmToHundredths(heightMm);
            var ps = new PaperSize("Custom", w, h) { RawKind = (int)PaperKind.Custom };
            doc.DefaultPageSettings.PaperSize = ps;
        }

        private void PrintFile(string path, Rule rule)
        {
            var targets = (rule.Printers == null || rule.Printers.Count == 0) ? new List<string?> { null } : rule.Printers.Cast<string?>().ToList();
            foreach (var printer in targets)
                PrintFileToPrinter(path, printer, rule);
        }

        private void PrintFileToPrinter(string path, string? printerName, Rule rule)
        {
            var ext = Path.GetExtension(path).ToLowerInvariant();
            if (ext == ".txt") PrintText(path, printerName, rule);
            else if (ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".bmp" || ext == ".gif" || ext == ".tif" || ext == ".tiff")
                PrintImage(path, printerName, rule);
            else
                ShellPrintTo(path, printerName);
        }

        private void PrintText(string path, string? printerName, Rule rule)
        {
            try
            {
                using var reader = new StreamReader(path);
                using var doc = new PrintDocument();
                if (!string.IsNullOrWhiteSpace(printerName))
                    doc.PrinterSettings = new PrinterSettings { PrinterName = printerName };
                ApplyPageSettings(doc, rule);
                doc.DocumentName = Path.GetFileName(path);
                var font = new Font("Consolas", 9);
                doc.PrintPage += (s, e) =>
                {
                    float linesPerPage = e.MarginBounds.Height / font.GetHeight(e.Graphics);
                    float y = e.MarginBounds.Top;
                    int count = 0;
                    string? line;
                    while (count < linesPerPage && (line = reader.ReadLine()) != null)
                    {
                        e.Graphics.DrawString(line, font, Brushes.Black, e.MarginBounds.Left, y);
                        y += font.GetHeight(e.Graphics);
                        count++;
                    }
                    e.HasMorePages = !reader.EndOfStream;
                };
                doc.Print();
                _log($"Print: {Path.GetFileName(path)} -> {(string.IsNullOrWhiteSpace(printerName) ? "Default" : printerName)}");
            }
            catch (Exception ex)
            {
                _log($"Error print {Path.GetFileName(path)}: {ex.Message}");
            }
        }

        private void PrintImage(string path, string? printerName, Rule rule)
        {
            try
            {
                using var img = Image.FromFile(path);
                using var doc = new PrintDocument();
                if (!string.IsNullOrWhiteSpace(printerName))
                    doc.PrinterSettings = new PrinterSettings { PrinterName = printerName };
                ApplyPageSettings(doc, rule);
                doc.DocumentName = Path.GetFileName(path);
                doc.PrintPage += (s, e) =>
                {
                    var bounds = e.MarginBounds;
                    var size = Fit(bounds.Size, img.Size);
                    var x = bounds.Left + (bounds.Width - size.Width) / 2;
                    var y = bounds.Top + (bounds.Height - size.Height) / 2;
                    e.Graphics.DrawImage(img, x, y, size.Width, size.Height);
                    e.HasMorePages = false;
                };
                doc.Print();
                _log($"Print: {Path.GetFileName(path)} -> {(string.IsNullOrWhiteSpace(printerName) ? "Default" : printerName)}");
            }
            catch (Exception ex)
            {
                _log($"Error print image {Path.GetFileName(path)}: {ex.Message}");
            }
        }

        private System.Drawing.Size Fit(System.Drawing.Size box, System.Drawing.Size img)
        {
            double scale = Math.Min((double)box.Width / img.Width, (double)box.Height / img.Height);
            return new System.Drawing.Size((int)(img.Width * scale), (int)(img.Height * scale));
        }

        private void ShellPrintTo(string path, string? printerName)
        {
            try
            {
                var psi = new ProcessStartInfo(path)
                {
                    Verb = string.IsNullOrWhiteSpace(printerName) ? "print" : "printto",
                    Arguments = string.IsNullOrWhiteSpace(printerName) ? "" : $"\"{printerName}\"",
                    CreateNoWindow = true,
                    UseShellExecute = true,
                    WindowStyle = ProcessWindowStyle.Hidden
                };
                using var p = Process.Start(psi);
                if (p != null) p.WaitForExit(15000);
                _log($"Print: {Path.GetFileName(path)} -> {(string.IsNullOrWhiteSpace(printerName) ? "Default" : printerName)}");
            }
            catch (Exception ex)
            {
                _log($"Shell print gagal: {ex.Message}");
            }
        }

        public void Dispose()
        {
            Stop();
        }
    }
}