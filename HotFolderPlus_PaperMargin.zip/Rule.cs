using System;
using System.Collections.Generic;

namespace HotFolderPlus
{
    /// <summary>
    /// Enum representing paper size modes for printing. Default uses printer settings;
    /// Thermal58 and Thermal80 correspond to typical thermal paper widths; Custom allows
    /// specifying width and height in millimeters.
    /// </summary>
    public enum PaperMode { Default, Thermal58, Thermal80, Custom }

    /// <summary>
    /// Represents a single hot-folder rule. Each rule defines a folder to monitor and
    /// actions to perform on matching files. New properties allow specifying paper size
    /// and margins for printing.
    /// </summary>
    public class Rule
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string Name { get; set; } = "Rule";
        public string SourceFolder { get; set; } = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        public string OutputFolder { get; set; } = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        public string Filter { get; set; } = "*.txt;*.pdf;*.png;*.jpg;*.jpeg";
        public List<string> Printers { get; set; } = new();

        // Paper and margin settings
        public PaperMode PaperMode { get; set; } = PaperMode.Default;
        public int CustomWidthMm { get; set; } = 58;
        public int CustomHeightMm { get; set; } = 200;
        public int MarginLeftMm { get; set; } = 5;
        public int MarginTopMm { get; set; } = 5;
        public int MarginRightMm { get; set; } = 5;
        public int MarginBottomMm { get; set; } = 5;

        public bool ActionPrint { get; set; } = true;
        public bool ActionCopyToOutput { get; set; } = false;
        public bool ActionMoveToOutput { get; set; } = false;
        public bool DeleteAfterProcessing { get; set; } = false;
        public bool Enabled { get; set; } = false;
    }

    /// <summary>
    /// Container for application configuration. Holds a list of rules to serialize/deserialize.
    /// </summary>
    public class AppConfig
    {
        public List<Rule> Rules { get; set; } = new();
    }
}